﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Web;
using System.Web.UI;
using System.Web.UI.WebControls;
using System.Configuration;
using System.Data;
using System.Drawing;
using System.Data.SqlClient;
using System.Text;
using System.Security.Cryptography;

namespace export
{
    public partial class login1 : System.Web.UI.Page
    {
        protected void Page_Load(object sender, EventArgs e)
        {
            Response.Cache.SetCacheability(HttpCacheability.NoCache);
        }

        protected void submit_Click(object sender, EventArgs e)
        {
           
            //Do MD5 Hashing...
            byte[] hs = new byte[50];
            string pass = TextBoxPass.Text;
            MD5 md5 = MD5.Create();
            byte[] inputBytes = System.Text.Encoding.ASCII.GetBytes(pass);
            byte[] hash = md5.ComputeHash(inputBytes);
            StringBuilder sb = new StringBuilder();
            for (int i = 0; i < hash.Length; i++)
            {
                hs[i] = hash[i];
                sb.Append(hs[i].ToString("x2"));
            }
            var hash_pass = sb.ToString();

            string connectionString = ConfigurationManager.ConnectionStrings["gt_ConStr"].ConnectionString;
            SqlCommand cmd = new SqlCommand("select COUNT(*)FROM tblClientRegistration WHERE Email='" + TextBoxemail.Text + "' and Password='" + hash_pass + "'");
            SqlConnection con = new SqlConnection(connectionString);
            cmd.Connection = con;
            cmd.CommandType = CommandType.Text;
            
            con.Open();
            int OBJ = Convert.ToInt32(cmd.ExecuteScalar());
            if (OBJ > 0)
            {
                if (CheckBox1.Checked)
                {
                    HttpCookie mycookie = new HttpCookie(TextBoxemail.Text, TextBoxPass.Text);
                    mycookie.Expires = DateTime.Now.AddDays(5);
                    Response.Cookies.Add(mycookie);
                }
                Session["email"] = TextBoxemail.Text;
                Response.Redirect("default.aspx");
            }
            else
            {
                Label1.Text = "Invalid username or password";
                this.Label1.ForeColor = Color.Red;
            }
        }

        protected void LinkButton2_Click(object sender, EventArgs e)
        {
            Response.Redirect("Registration.aspx");
        }
    }
}
